package model;

public class Session {
    public static String role;
    public static String ma;
}
